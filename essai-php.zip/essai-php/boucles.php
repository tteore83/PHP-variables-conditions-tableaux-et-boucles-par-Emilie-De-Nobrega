<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Boucles PHP</title>
</head>

<body>

  <!--LES BOUCLES-->
  <!--WHILE-->
  <!--génération de la table de multiplication du 9 pour voir la boucle-->
<!--<?php $index = 0;
      while ($index <= 10) {
        echo '9 x '. $index. ' = '. (9 * $index) . ' , ';
        $index++; //incrémentation à la fin pour stopper la boucle
      } ?>  -->


  <!--DO WHILE-->
  <!--<?php $index = 0;
      do {
        echo '9 x ', $index, ' = ', (9 * $index), ' , ';
        $index++;
      } while ($index <= 10);
      ?> -->

  <!--FOR-->
  <!--Création d'un tableau-->
  <!--<?php $villes = ['Auxerre', 'Paris', 'Lyon', 'Rouen', 'La Rochelle', 'Toulouse'];
      $number = count($villes); //Comptage du nombres de données

      for ($i = 0; $i < $number; $i++) { //Boucle à 'linterieur du tableau avec recuperation de la taille
        echo $villes[$i] . ' , '; //Affiche le nb d'élements présents
      }
      ?> -->


  <!--FOREACH-->
<!--
<?php $array = ['premier' => 'N° 1', 'deuxieme' => 'N° 2', 'troisieme' => 'N° 3'];
  echo $array['deuxieme'];
        ?> 
	
<?php foreach ($array as $mobile) //recupere dans la tableau la valeur de l'index
  echo $mobile . ' , ';
?> 
-->

  <!--BREAK-->
  <!--Sortie de boucle sans conditon préalablement definies-->
  <!-- <?php $i = 1;
        while (true) // condition de boucle toujours vraie
        {
          echo $i . ' , ';
          $i++; // incrémentation à la fin de la condition! 
          if ($i == 5) // test de sortie de boucle
            break; // sortie de boucle
        }
        ?> -->


  <!--CONTINUE-->
  <!--
	<?php $tableau = [28, 14, 4, 46, 'Suite'];
  foreach ($tableau as $item) {
    if ($item === 4) { // retire le passage du nombre'4'
      continue;
    }
    echo $item . ' , ';
  }
  ?> -->
</body>

</html>