<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Conditions PHP</title>
</head>

<body>

    <!--If -->
 <?php $age = 32;

        if ($age == 32){ // $age strictement identique à 32
            echo 'Vous avez 32 ans!';  }// affiche le message
        ?> 

    <!-- Plusieurs conditions-->
   <!-- <?php $age = 49;
            if ($age == 49) {
                echo 'Vous avez 49 ans' . ' .';
                echo ' Bientôt la cinquantaine ...';
            }
            ?> -->


    <!-- ElseIf -->
    <!-- <?php $personne = 'John';
            if ($personne === 'Jane') {
                echo 'Hello Jane !';
            } elseif ($personne === 'Sarah') {
                echo 'Hello Sarah !';
            } elseif ($personne === 'John') {
                echo 'Hello John !';
            } else {
                echo 'Ben... tu es qui ?';
            }
            ?> -->


<!-- <?php
    if ($age < 24)
        echo 'Vous avez plus 25 ans';
    else
        echo 'Vous n\'avez pas 25 ans';
    ?> -->


<!-- If - elseif - if-->
<!-- <?php
if( $age < 14 ) // si $age est plus petit que < 14, 
  echo 'Vous avez moins de 14 ans'; // alors affiche : 
else if( $age <= 18 ) // sinon, si $age plus petit ou égal à 18, 
  echo 'Vous avez entre 14 et 18 ans'; //alors, affiche : 
else if( $age <= 25 ) // sinon, si $age plus petit ou égal à 25
  echo 'Vous avez entre 19 et 25 ans';
else if( $age <= 64 ) // sinon, si $age plus petit ou égal à 64
  echo 'Vous avez entre 26 et 64 ans';
else // sinon
  echo 'Vous avez plus de 64 ans!'; 
?> -->


</body>

</html>