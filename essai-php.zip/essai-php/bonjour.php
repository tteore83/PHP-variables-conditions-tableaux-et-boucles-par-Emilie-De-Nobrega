<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Intro PHP</title>
</head>

<body>

    <!--LES VARIABLES-->

    <!-- déclaration variable et affichage navigateur -->
    <!--<?php echo $age = 12; ?>-->

    <!--variable dynamique-->
    <!--<?php
        $a = 'bonjour';
        $$a = 'monde';
        echo "$a ${$a}"; ?> -->


  <!--chaine de caractères (string) -->
   <!-- <?php
    $age = 25;
    $name = 'téo';
    echo "<p>la variable age contient : ". $age . '</p>';
    echo "la variable prenom contient : " . $name;
?>-->


    <!-- float (nbs à virgules)
    <?php $num = 1.568;
    echo $num; ?> -->


    <!--Concaténation chaine de caractères-->
    <!--<?php $good = 'bonne';
        echo "Bonjour à vous, et $good journée"; ?> -->


   <!--<?php $intro = ' Introduction ';
        $body = 'PHP';
        $fin = 'courage';
        $titre = $intro . $body . ". Ca va $body aller ," . $fin . '!';
        echo $titre;  ?> -->


    <!--LES TABLEAUX-->

    <!-- <?php $fruits = ['poire', 'pomme', 'ananas', 'clémentine', 'mangue', 'grenade'];
            echo $fruits[5]; ?>  -->
    <!--Demande d'affichage de l'index 8-->
    <!-- echo $fruits[8]; -->
    <!--Ajout d'un fruit-->
    <!-- $fruits[] = 'grenade'; -->
    <!--efface 'pomme' mais ne modifie pas les numéros d'index des autres. 
    par exemple, 'ananas' garde l'index 2-->
    <!--unset$fruits([1]);-->


    <!-- TABLEAU ASSOCIATIF-->
    <!--Déclaration des différentes tables du tableau-->
    <!-- <?php $client = [
                'day' => '12',
                'month' => "février",
                'year' => 37
            ];
            echo  'Vous êtes né le' . ' ' . $client['day'] . ' ' . 'du mois de' .
                ' ' . $client['month'] . ' .' . 'Vous avez donc ' . ' 
    ' . $client['year'] . ' ' . 'ans'  ?>  -->




    </form>
</body>

</html>